# neighborhood = {
#     "Buttes-Montmartre": 0,
#     "Popincourt": 1,
#     "Batignolles-Monceau": 2,
#     "Vaugirard": 3,
#     "Passy": 4,
#     "Entrepôt": 5,
#     "Buttes-Chaumont": 6,
#     'Ménilmontant': 7,
#     'Reuilly': 8,
#     'Opéra': 9,
#     'Observatoire': 10,
#     'Temple': 11,
#     'Gobelins': 12,
#     'Bourse': 13,
#     'Hôtel-de-Ville': 14,
#     'Panthéon': 15,
#     'Élysée': 16,
#     'Luxembourg': 17,
#     'Palais-Bourbon': 18,
#     'Louvre': 19
# }

numerical = (
     "host_is_superhost",
     "host_total_listings_count",
     'latitude',
     'longitude', 'accommodates', 'bathrooms', 'minimum_nights',
     'maximum_nights', 'availability_90', 'number_of_reviews',
     'review_scores_accuracy', 'calculated_host_listings_count'
)
categorical = (
    "host_response_time",
    "neighbourhood",
    "property_type",
    "room_type",
    "time_since_first_review",
    "time_since_last_review"
)
bins = (
    "review_scores_rating",
    "time_since_first_review",
    "time_since_last_review"
)
amenities = (
    'air_conditioning', 'bed_linen', 'tv', 'coffee_machine',
    'cooking_basics', 'white_goods', 'elevator', 'parking',
    'host_greeting', 'internet', 'long_term_stays', 'private_entrance'
)